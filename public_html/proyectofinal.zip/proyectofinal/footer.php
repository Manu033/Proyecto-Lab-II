<head>
    <!--<link rel="stylesheet" href="style.css"> !-->
</head>
<body>
<footer>
        <div class="sociales-metodo">
            <i class="fas fa-map-marked-alt"></i>
            <span>Lorem ipsum dolor sit, amet consectetur adipisicing elit. </span>
        </div>

        <div class="sociales-metodo">
            <i class="fas fa-envelope"></i>
            <span>mecanical@Workshop.com </span>
        </div>

        <div class="sociales-metodo">
            <i class="fas fa-phone"></i>
            <span>+5694830484</span>
        </div>  

        <div class="sociales-metodo">
            <i class="fa-brands fa-instagram"></i>
            <span>@tallermecanico </span>
        </div>  
</footer>
<script src="./app.js"></script>    
</body>
